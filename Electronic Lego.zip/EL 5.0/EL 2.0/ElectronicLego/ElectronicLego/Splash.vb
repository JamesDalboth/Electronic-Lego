﻿Public Class Splash
    Dim endcount = 0
    Private Sub Splash_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.ClientSize = New Point(496, 303)
        Me.BackgroundImage = My.Resources.Splash4
        If My.Application.Info.Title <> "" Then
            ApplicationTitle.Text = My.Application.Info.Title
        Else
            ApplicationTitle.Text = System.IO.Path.GetFileNameWithoutExtension(My.Application.Info.AssemblyName)
        End If
        Version.Text = System.String.Format(Version.text, My.Application.Info.Version.Major, My.Application.Info.Version.Minor)
        copyright.text = My.Application.Info.Copyright
    End Sub
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        endcount += 1
        If endcount > 3 Then
            MainForm.Show()
            MainForm.Focus()
            Me.Hide()
        End If
    End Sub

End Class