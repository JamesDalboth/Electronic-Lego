﻿' PORT CLASS
Public Class port
    Public location As Point
    Public PortGate As Gate
    Public PortWire As New List(Of Wire)
    Public Type As Boolean = False
    Public State As Boolean = False
    Public Sub New(ByVal X As Integer, ByVal Y As Integer, ByVal Typ As Boolean, ByRef Parent As Gate)
        location = New Point(X, Y)
        Type = Typ
        PortGate = Parent
    End Sub
    Public Function getlocation() As Point
        Return New Point(location.X + PortGate.Position.X, location.Y + PortGate.Position.Y)
    End Function
    Public Function getlocationRect() As Rectangle
        Return New Rectangle(New Point(location.X + PortGate.Position.X, location.Y + PortGate.Position.Y), New Size(10, 10))
    End Function
End Class
