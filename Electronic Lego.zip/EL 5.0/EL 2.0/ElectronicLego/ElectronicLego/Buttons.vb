﻿
Public Class Button
    Public Location As Point
    Public Image As Bitmap = Nothing
    Public Overridable Sub Draw(ByRef GTX As Graphics)
        GTX.DrawImage(Image, Location)
    End Sub
    Public Overridable Sub Click(ByRef Sim As CustomScreen, ByVal X As Integer, ByVal Y As Integer)
        My.Computer.Audio.Play(My.Resources.SpawnClick, AudioPlayMode.Background)
    End Sub
    Public Function Rect() As Rectangle
        Return New Rectangle(Location, New Size(100, 100))
    End Function
End Class
Public Class Cloner
    Inherits Button
    Public GateToClone
    Public Sub New(ByRef GTC As Gate, ByVal Pos As Point)
        GateToClone = GTC
        Location = Pos
    End Sub
    Public Overrides Sub Draw(ByRef GTX As Graphics)
        GTX.DrawImage(GateToClone.Image, Location)
    End Sub
    Public Overrides Sub Click(ByRef CS As CustomScreen, ByVal X As Integer, ByVal Y As Integer)
        If CS.WireMode = True Then
            CS.DestroyCurrentWire()
            CS.WireMode = False
        End If
        Dim NewGate As Gate
        If GateToClone.Name = "CUST" Then
            NewGate = GateToClone.Clone(X - 50, Y - 50, GateToClone.CircuitNumber)
        Else
            NewGate = GateToClone.Clone(X - 50, Y - 50)
        End If
        CS.Gates.Add(NewGate)
        CS.MovingGate = NewGate
        MyBase.Click(CS, X, Y)
    End Sub
End Class


Public Class WireButton
    Inherits Button
    Public Sub New(ByVal pos As Point)
        Image = My.Resources.Wires
        Location = pos
    End Sub
    Public Overrides Sub Draw(ByRef GTX As System.Drawing.Graphics)
        GTX.DrawImage(Image, Location)
    End Sub
    Public Overrides Sub Click(ByRef CS As CustomScreen, ByVal X As Integer, ByVal Y As Integer)
        If CS.WireMode = False Then
            CS.NewWire()
        Else
            CS.DestroyCurrentWire()
        End If
        CS.WireMode = Not CS.WireMode
        MyBase.Click(CS, X, Y)
    End Sub
End Class


Public Class QuitButton
    Inherits Button
    Public Sub New(ByVal Pos As Point)
        Location = Pos
        Image = My.Resources.Quit
    End Sub
    Public Overrides Sub Draw(ByRef GTX As System.Drawing.Graphics)
        GTX.DrawImage(Image, Location)
    End Sub
    Public Overrides Sub Click(ByRef sim As CustomScreen, X As Integer, Y As Integer)
        sim.Exitapp = True
        MyBase.Click(sim, X, Y)
    End Sub
End Class

Public Class SaveButton
    Inherits Button
    Public Number As Integer
    Public Sub New(ByVal Nmb As Integer, ByVal Pos As Point)
        Number = Nmb
        Location = Pos
        Image = My.Resources.Save
    End Sub
    Public Overrides Sub Click(ByRef CS As CustomScreen, ByVal X As Integer, ByVal Y As Integer)
        If CS.Saving = False Then

            Dim BlankBitmap As Bitmap = CS.Image.Clone
            Dim Device As Graphics = Graphics.FromImage(BlankBitmap)
            Dim StringWidth = CS.Image.Width \ 5
            Device.DrawString("SAVING", New Font("Consolas", StringWidth \ 5, FontStyle.Bold), Brushes.Gray, New Point((CS.Image.Width \ 2) - (StringWidth / 2), CS.Image.Height \ 2))
            CS.Image = BlankBitmap
            Application.DoEvents()
            CS.Saving = True
            Dim File As String = ""
            Select Case Number
                Case 1
                    File = "Custom1Table.csv"
                Case 2
                    File = "Custom2Table.csv"
                Case 3
                    File = "Custom3Table.csv"
                Case 4
                    File = "Custom4Table.csv"
            End Select
            FileOpen(1, File, OpenMode.Output)
            Dim output As String = ""
            For i = 0 To 15
                Dim bin As String = Convert.ToString(i, 2).PadLeft(4, "0"c)
                For count = 0 To 3
                    Select Case Mid(bin, count + 1, 1)
                        Case 0
                            CS.Gates(count).State = True
                            output += "1"
                        Case 1
                            CS.Gates(count).State = False
                            output += "0"
                    End Select
                    output += ","
                Next
                For J = 0 To 100
                    CS.CheckStates()
                Next
                For count = 4 To 7
                    Select Case CS.Gates(count).Inputs(0).State
                        Case True
                            output += "1"
                        Case False
                            output += "0"
                    End Select
                    output += ","
                Next
                output += vbCrLf
            Next
            Print(1, output)

            FileClose(1)
            MsgBox("SAVED")
            CS.Saving = False
        Else
            MsgBox("WAIT")
        End If
        MyBase.Click(CS, X, Y)
    End Sub
End Class