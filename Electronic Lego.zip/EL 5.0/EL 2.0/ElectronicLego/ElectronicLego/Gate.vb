﻿
'' OVERARCHING GATE
Public Class Gate
    Public Name As String
    Public Image As Bitmap
    Public Position As Point
    Public Inputs As New List(Of port)
    Public Outputs As New List(Of port)
    'Table stores the truth table
    Public Table(,) As Boolean
    Public State As Boolean
    Public Overridable Sub Click(ByVal X As Integer, ByVal Y As Integer, ByRef MovingGate As Gate, ByRef GateList As List(Of Gate))
        GateList.Remove(Me)
        MovingGate = Me
        GateList.Add(Me)
        My.Computer.Audio.Play(My.Resources.SpawnClick, AudioPlayMode.Background)
    End Sub
    Public Sub Destroy()
        For Each Inp In Inputs.ToList()
            For Each Wire In Inp.PortWire.ToList()
                If Not Wire Is Nothing Then
                    Wire.Destory()
                End If
            Next

        Next
        For Each Out In Outputs.ToList()
            For Each Wire In Out.PortWire.ToList()
                If Not Wire Is Nothing Then
                    Wire.Destory()
                End If
            Next
        Next
        MyBase.Finalize()
    End Sub
    Public Sub FillTable(ByRef Table(,) As Boolean, ByVal FileName As String)
        FileOpen(1, FileName, OpenMode.Input)
        For RowCount = 0 To Table.GetLength(1) - 1
            Dim Row As String = LineInput(1)
            For ColumCount = 0 To Table.GetLength(0) - 1
                Dim Entity As SByte = Mid(Row, ColumCount * 2 + 1, 1)
                Table(ColumCount, RowCount) = Entity
            Next
        Next
        FileClose(1)
    End Sub
    Public Overridable Function Clone(ByVal X As Integer, ByVal Y As Integer)
        Return Nothing
    End Function
    Public Overridable Function Clone(ByVal X As Integer, ByVal Y As Integer, ByVal Number As Integer)
        Return Nothing
    End Function
    Public Overridable Sub CheckState()
        'If No wires connected to input then set input to off
        For Each Inp In Inputs
            If Inp.PortWire.Count = 0 Then
                Inp.State = False
            End If
        Next
        'If no wires connected to output the set output to off
        For Each Out In Outputs
            If Out.PortWire.Count = 0 Then
                Out.State = False
            End If
        Next

        'Dimesnion the temp TruthTable
        Dim TempTable(Table.GetLength(0) - 1, Table.GetLength(1) - 1) As Integer
        For i = 0 To Table.GetLength(0) - 1
            For j = 0 To Table.GetLength(1) - 1
                TempTable(i, j) = Table(i, j)
            Next
        Next
        'Create temp widths and heights that will change throughout the checking
        Dim TempHeight = Table.GetLength(1)
        Dim TempWidth = Table.GetLength(0)
        For Each Inp In Inputs.ToList()
            ' New table will be half the height
            TempHeight /= 2
            ' 1 less the width
            TempWidth -= 1
            ' Create a new empty table for next table state
            Dim Temp(TempHeight - 1, TempWidth - 1) As Integer
            '' If the input is on
            If Inp.State = True Then
                Temp = SpliceTable(TempTable, 0, TempHeight, TempWidth)
            Else
                Temp = SpliceTable(TempTable, 1, TempHeight, TempWidth)
            End If
            ReDim TempTable(TempWidth - 1, TempHeight - 1)
            For i = 0 To TempWidth - 1
                For j = 0 To TempHeight - 1
                    TempTable(i, j) = Temp(i, j)
                Next
            Next
        Next
        For i = 0 To Outputs.Count - 1
            Outputs(i).State = TempTable(i, 0)
        Next
    End Sub
    Public Function SpliceTable(ByVal Table(,) As Integer, ByVal Half As Integer, ByVal Height As Integer, ByVal Width As Integer) As Integer(,)
        Dim TempTable(Width - 1, Height - 1) As Integer
        For i = 0 To Height - 1
            For j = 0 To Width - 1
                TempTable(j, i) = Table(j + 1, Half * (Height) + i)
            Next
        Next
        Return TempTable
    End Function
End Class
'' AND GATE
Public Class AndGate
    Inherits Gate
    Public Sub New(ByVal X As Integer, ByVal Y As Integer)
        Name = "AND"
        Image = My.Resources.AndGate
        Position = New Point(X, Y)
        Inputs.Add(New port(0, 10, True, Me))
        Inputs.Add(New port(0, 80, True, Me))
        Outputs.Add(New port(90, 45, False, Me))
        ReDim Table(Inputs.Count, 2 ^ Inputs.Count - 1)
        FillTable(Table, "AndTable.csv")
    End Sub
    Public Overrides Function Clone(ByVal X As Integer, ByVal Y As Integer)
        Return New AndGate(X, Y)
    End Function
End Class
'' ORGATE
Public Class OrGate
    Inherits Gate
    Public Sub New(ByVal X As Integer, ByVal Y As Integer)
        Name = "OR"
        Image = My.Resources.OrGate
        Position = New Point(X, Y)
        Inputs.Add(New port(0, 10, True, Me))
        Inputs.Add(New port(0, 80, True, Me))
        Outputs.Add(New port(90, 45, False, Me))
        ReDim Table(Inputs.Count, 2 ^ Inputs.Count - 1)
        FillTable(Table, "OrTable.csv")
    End Sub
    Public Overrides Function Clone(ByVal X As Integer, ByVal Y As Integer)
        Return New OrGate(X, Y)
    End Function
End Class
''Not Gate
Public Class NotGate
    Inherits Gate
    Public Sub New(ByVal X As Integer, ByVal Y As Integer)
        Name = "NOT"
        Image = My.Resources.NotGate
        Position = New Point(X, Y)
        Inputs.Add(New port(0, 45, True, Me))
        Outputs.Add(New port(90, 45, False, Me))
        ReDim Table(Inputs.Count, 2 ^ Inputs.Count - 1)
        FillTable(Table, "NotTable.csv")
    End Sub
    Public Overrides Function Clone(ByVal X As Integer, ByVal Y As Integer)
        Return New NotGate(X, Y)
    End Function
End Class
'' XOR
Public Class XorGate
    Inherits Gate
    Public Sub New(ByVal X As Integer, ByVal Y As Integer)
        Name = "XOR"
        Image = My.Resources.XorGate
        Position = New Point(X, Y)
        Inputs.Add(New port(0, 10, True, Me))
        Inputs.Add(New port(0, 80, True, Me))
        Outputs.Add(New port(90, 45, False, Me))
        ReDim Table(Inputs.Count, 2 ^ Inputs.Count - 1)
        FillTable(Table, "XorTable.csv")
    End Sub
    Public Overrides Function Clone(ByVal X As Integer, ByVal Y As Integer)
        Return New XorGate(X, Y)
    End Function
End Class
'' NOR
Public Class NorGate
    Inherits Gate
    Public Sub New(ByVal X As Integer, ByVal Y As Integer)
        Name = "NOR"
        Image = My.Resources.NorGate
        Position = New Point(X, Y)
        Inputs.Add(New port(0, 10, True, Me))
        Inputs.Add(New port(0, 80, True, Me))
        Outputs.Add(New port(90, 45, False, Me))
        ReDim Table(Inputs.Count, 2 ^ Inputs.Count - 1)
        FillTable(Table, "NorTable.csv")
    End Sub
    Public Overrides Function Clone(ByVal X As Integer, ByVal Y As Integer)
        Return New NorGate(X, Y)
    End Function
End Class
'' NAND
Public Class NandGate
    Inherits Gate
    Public Sub New(ByVal X As Integer, ByVal Y As Integer)
        Name = "NAND"
        Image = My.Resources.NandGate
        Position = New Point(X, Y)
        Inputs.Add(New port(0, 10, True, Me))
        Inputs.Add(New port(0, 80, True, Me))
        Outputs.Add(New port(90, 45, False, Me))
        ReDim Table(Inputs.Count, 2 ^ Inputs.Count - 1)
        FillTable(Table, "NandTable.csv")
    End Sub
    Public Overrides Function Clone(ByVal X As Integer, ByVal Y As Integer)
        Return New NandGate(X, Y)
    End Function
End Class
'' CUSTOM
Public Class Custom
    Inherits Gate
    Public CircuitNumber As Integer
    Public Sub New(ByVal X As Integer, ByVal Y As Integer, ByVal Number As Integer)
        CircuitNumber = Number
        Name = "CUST"
        Position = New Point(X, Y)
        Inputs.Add(New port(0, 0, True, Me))
        Inputs.Add(New port(0, 25, True, Me))
        Inputs.Add(New port(0, 65, True, Me))
        Inputs.Add(New port(0, 90, True, Me))
        Outputs.Add(New port(90, 0, False, Me))
        Outputs.Add(New port(90, 25, False, Me))
        Outputs.Add(New port(90, 65, False, Me))
        Outputs.Add(New port(90, 90, False, Me))
        ReDim Table(Inputs.Count - 1 + Outputs.Count, 2 ^ Inputs.Count - 1)
        Image = My.Resources.CustomCircuit
        Select Case Number
            Case 1
                FillTable(Table, "Custom1Table.csv")
            Case 2
                FillTable(Table, "Custom2Table.csv")
            Case 3
                FillTable(Table, "Custom3Table.csv")
            Case 4
                FillTable(Table, "Custom4Table.csv")
        End Select
    End Sub
    Public Overrides Function Clone(ByVal X As Integer, ByVal Y As Integer, ByVal Number As Integer)
        Return New Custom(X, Y, Number)
    End Function
End Class

'' BATTERY and BULB are special class gates as they either have only a input or an output making truth tables redunant. To fix this they override the check sub class
'' Bulb
Public Class Bulb
    Inherits Gate
    Public Sub New(ByVal X As Integer, ByVal Y As Integer)
        Name = "BULB"
        Image = My.Resources.NotGate
        Position = New Point(X, Y)
        Inputs.Add(New port(0, 45, True, Me))
    End Sub
    Public Overrides Sub CheckState()
        If Inputs(0).PortWire.Count = 0 Then Inputs(0).State = False
        If Inputs(0).State = True Then
            Image = My.Resources.BulbOn
        Else
            Image = My.Resources.BulbOff
        End If
    End Sub
    Public Overrides Sub Click(ByVal X As Integer, ByVal Y As Integer, ByRef MovingGate As Gate, ByRef GateList As List(Of Gate))

    End Sub
End Class
'' BATTERY
Public Class Battery
    Inherits Gate
    Public Sub New(ByVal X As Integer, ByVal Y As Integer)
        Name = "BAT"
        Image = My.Resources.BatteryOff
        Position = New Point(X, Y)
        Outputs.Add(New port(90, 45, False, Me))
    End Sub
    Public Overrides Sub CheckState()
        For Each Out In Outputs
            Out.State = State
            Select Case State
                Case False
                    Image = My.Resources.BatteryOff
                Case True
                    Image = My.Resources.BatteryOn
            End Select
        Next
    End Sub
    Public Overrides Sub Click(ByVal X As Integer, ByVal Y As Integer, ByRef MovingGate As Gate, ByRef GateList As List(Of Gate))
        My.Computer.Audio.Play(My.Resources.Click, AudioPlayMode.Background)
        State = Not State
    End Sub
End Class

