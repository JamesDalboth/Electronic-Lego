﻿Public Class MainForm
    '' ===================LOOP SUBS====================
    Private Sub MainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim ScreenWidth = My.Computer.Screen.WorkingArea.Width
        Dim ScreenHeight = My.Computer.Screen.WorkingArea.Height - 100
        Dim ApplicationWidth As Integer
        Dim ApplicationHeight As Integer
        If (ScreenWidth / ScreenHeight) > (13 / 8) Then
            ApplicationHeight = (ScreenHeight - 20)
            ApplicationWidth = (Int(ApplicationHeight * 13 / 8))
        Else
            ApplicationWidth = (ScreenWidth - 20)
            ApplicationHeight = (Int(ApplicationWidth * 8 / 13))
        End If

        Dim CS As CustomScreen
        'Creates FormSetup
        Me.ClientSize = New Size(ApplicationWidth, ApplicationHeight)
        Me.FormBorderStyle = Windows.Forms.FormBorderStyle.FixedSingle
        Me.Location = New Point(0, 0)
        CS = New CustomScreen() With {.Location = New Point(0, 0), .Size = New Size(ApplicationWidth, ApplicationHeight), .Parent = Me}

        'Creates Custom eventhandlers
        AddHandler CS.MouseDown, AddressOf CSMouseDown
        AddHandler CS.MouseMove, AddressOf CSMouseMove
        'runs main program on loop
        CS.StartGame()
        Main(CS, ApplicationWidth, ApplicationHeight)
    End Sub
    Public Sub Main(ByVal CS As CustomScreen, ByVal ApplicationWidth As Integer, ByVal ApplicationHeight As Integer)
        Application.DoEvents()
        Me.Show()
        Dim CurrentTime As Long = Now.Ticks()
        Dim LastTime As Long = Now.Ticks()
        '' PLACE FIXED BATTERYS
        CS.Gates.Add(New Battery(210, 10))
        CS.Gates.Add(New Battery(210, 200))
        CS.Gates.Add(New Battery(210, 500))
        CS.Gates.Add(New Battery(210, 690))
        '' PLACE FIXED BULBS
        CS.Gates.Add(New Bulb(890, 10))
        CS.Gates.Add(New Bulb(890, 200))
        CS.Gates.Add(New Bulb(890, 500))
        CS.Gates.Add(New Bulb(890, 690))
        '' PLACE CLONERS
        CS.Buttons.Add(New Cloner(New AndGate(0, 0), New Point(0, 0))) '0
        CS.Buttons.Add(New Cloner(New OrGate(0, 0), New Point(100, 0))) '1
        CS.Buttons.Add(New Cloner(New NorGate(0, 0), New Point(0, 100))) '2
        CS.Buttons.Add(New Cloner(New NotGate(0, 0), New Point(100, 100))) '3
        CS.Buttons.Add(New Cloner(New NandGate(0, 0), New Point(0, 200))) '4
        CS.Buttons.Add(New Cloner(New XorGate(0, 0), New Point(100, 200))) '5
        CS.Buttons.Add(New Cloner(New Custom(0, 0, 1), New Point(0, 300))) '6
        CS.Buttons.Add(New Cloner(New Custom(0, 0, 2), New Point(0, 400))) '7
        CS.Buttons.Add(New Cloner(New Custom(0, 0, 3), New Point(0, 500))) '8
        CS.Buttons.Add(New Cloner(New Custom(0, 0, 4), New Point(0, 600))) '9
        CS.Buttons.Add(New WireButton(New Point(0, 700))) '10
        CS.Buttons.Add(New QuitButton(New Point(100, 700))) '11
        CS.Buttons.Add(New SaveButton(1, New Point(100, 300))) '12
        CS.Buttons.Add(New SaveButton(2, New Point(100, 400))) '13
        CS.Buttons.Add(New SaveButton(3, New Point(100, 500))) '14
        CS.Buttons.Add(New SaveButton(4, New Point(100, 600))) '15
        Dim Device As Graphics = Graphics.FromImage(CS.Background)
        Device.DrawImage(My.Resources.TempBackground, 0, 0)
        DrawMenu(Device, CS)
        '' RUN GAME LOOP
        While CS.Exitapp = False
            CurrentTime = Now.Ticks
            If CurrentTime - LastTime >= 16 Then
                CS.CheckStates()
                DrawGraphics(CS)
                If Me.Visible = False Then
                    CS.Exitapp = True
                End If
                Application.DoEvents()
                LastTime = CurrentTime
            End If
        End While
        Application.Exit()
    End Sub

    '' UNDOS LAST WIRE
    '' ==================DRAW ITEMS SUB================
    Public Sub DrawGraphics(ByVal CS As CustomScreen)
        Dim Surface As Bitmap = CS.Background.Clone
        Dim Device As Graphics = Graphics.FromImage(Surface)
        DrawWires(Device, CS)
        DrawGates(Device, CS)
        DrawSelection(Device, CS)
        DrawTruthTable(Device, CS)
        DrawLabels(Device)
        CS.Image = ResizeImage(Surface, CS.Size)
        Application.DoEvents()
    End Sub
    Public Function ResizeImage(ByVal InputImage As Image, ByVal Sz As Size) As Image
        Return New Bitmap(InputImage, Sz)
    End Function
    Public Sub DrawMenu(ByVal Device As Graphics, ByRef CS As CustomScreen)
        For Each Btn In CS.Buttons
            Btn.Draw(Device)
        Next
    End Sub
    Public Sub DrawLabels(ByVal Device As Graphics)
        Dim Font As New Font("Consolas", 12, FontStyle.Bold)
        Device.DrawString("I0", Font, Brushes.Black, New Point(250, 70))
        Device.DrawString("I1", Font, Brushes.Black, New Point(250, 260))
        Device.DrawString("I2", Font, Brushes.Black, New Point(250, 560))
        Device.DrawString("I3", Font, Brushes.Black, New Point(250, 750))
        Device.DrawString("O0", Font, Brushes.Black, New Point(940, 70))
        Device.DrawString("O1", Font, Brushes.Black, New Point(940, 260))
        Device.DrawString("O2", Font, Brushes.Black, New Point(940, 560))
        Device.DrawString("O3", Font, Brushes.Black, New Point(940, 750))
    End Sub
    Public Sub DrawSelection(ByVal Device As Graphics, ByRef CS As CustomScreen)
        Dim WPRed = New Pen(Brushes.Goldenrod)
        WPRed.Width = 5
        If CS.WireMode = True Then
            Device.DrawRectangle(WPRed, CS.Buttons(10).Rect())
        Else
            If Not (CS.MovingGate Is Nothing) Then
                Select Case CS.MovingGate.Name
                    Case "AND"
                        Device.DrawRectangle(WPRed, CS.Buttons(0).Rect())
                    Case "NOR"
                        Device.DrawRectangle(WPRed, CS.Buttons(2).Rect())
                    Case "NAND"
                        Device.DrawRectangle(WPRed, CS.Buttons(4).Rect())
                    Case "OR"
                        Device.DrawRectangle(WPRed, CS.Buttons(1).Rect())
                    Case "NOT"
                        Device.DrawRectangle(WPRed, CS.Buttons(3).Rect())
                    Case "XOR"
                        Device.DrawRectangle(WPRed, CS.Buttons(5).Rect())
                    Case "CUST"
                        Select Case CType(CS.MovingGate, Custom).CircuitNumber
                            Case 1
                                Device.DrawRectangle(WPRed, CS.Buttons(6).Rect())
                            Case 2
                                Device.DrawRectangle(WPRed, CS.Buttons(7).Rect())
                            Case 3
                                Device.DrawRectangle(WPRed, CS.Buttons(8).Rect())
                            Case 4
                                Device.DrawRectangle(WPRed, CS.Buttons(9).Rect())
                        End Select
                End Select
            End If
        End If
    End Sub
    Public Sub DrawGates(ByVal Device As Graphics, ByRef CS As CustomScreen)
        For Each Gate In CS.Gates
            Device.DrawImage(Gate.Image, Gate.Position)
            DrawPorts(Device, Gate)
        Next
    End Sub
    Public Sub DrawWires(ByVal Device As Graphics, ByRef CS As CustomScreen)
        '' CREATE BLACK PEN TO DRAW OFF WIRE
        Dim WPBlack = New Pen(Brushes.Black)
        WPBlack.Width = 5
        '' CREATE GOLD PEN TO DRAW ON WIRE
        Dim WPGold = New Pen(Brushes.Gold)
        WPGold.Width = 5
        '' DRAW EACH WIRE WITH EACH APPROPRIATE COLOR
        For Each Wire In CS.Wires
            If Not (Wire.Port2 Is Nothing) Then
                If Wire.State = False Then
                    Device.DrawLine(WPBlack, New Point(Wire.Port1.getlocation.X + 5, Wire.Port1.getlocation.Y + 5), New Point(Wire.Port2.getlocation.X + 5, Wire.Port2.getlocation.Y + 5))
                Else
                    Device.DrawLine(WPGold, New Point(Wire.Port1.getlocation.X + 5, Wire.Port1.getlocation.Y + 5), New Point(Wire.Port2.getlocation.X + 5, Wire.Port2.getlocation.Y + 5))
                End If
            ElseIf Not Wire.Port1 Is Nothing Then
                Device.DrawLine(WPBlack, New Point(Wire.Port1.getlocation.X + 5, Wire.Port1.getlocation.Y + 5), New Point((Cursor.Position.X - Me.Location.X - 5) * 1300 / CS.Size.Width, (Cursor.Position.Y - Me.Location.Y - 20) * 800 / CS.Size.Height))
            End If
        Next
    End Sub
    Public Sub DrawPorts(ByVal Device As Graphics, ByRef Gate As Gate)
        '' GOES THOUGH EACH PORT CONNECTED TO EACH WIRE AND DRAW BLUE SQAURES TO SIGNIFY THEYRE ON
        For Each Port In Gate.Inputs
            If Port.PortWire.Count > 0 Then
                Device.FillRectangle(Brushes.Blue, Port.getlocationRect)
            End If
        Next
        For Each Port In Gate.Outputs
            If Port.PortWire.Count > 0 Then
                Device.FillRectangle(Brushes.Blue, Port.getlocationRect)
            End If
        Next
    End Sub
    Public Sub DrawTruthTable(ByVal Device As Graphics, ByRef CS As CustomScreen)
        Dim Font As New Font("Consolas", 12, FontStyle.Bold)
        Dim Pen = New Pen(Brushes.Blue)
        Pen.Width = 5
        Dim Title As String
        Dim Table(,) As Boolean
        If Not CS.MovingGate Is Nothing Then
            Title = CS.MovingGate.Name
            Table = CS.MovingGate.Table
        Else
            Title = "OBJECTIVE"
            Table = CS.Table
        End If
        Dim TitleX As Integer = 1000 + 150 - (TextRenderer.MeasureText(Title, Font).Width \ 2)
        Dim StartX As Integer = 1000 + ((300 - (Table.GetLength(0) + 1) * 22.5) \ 2)
        Dim StartY As Integer = (800 - (Table.GetLength(1) + 1) * 22.5) \ 2
        Device.DrawString(Title, Font, Brushes.Black, TitleX, StartY - 100)
        For i = 0 To Table.GetLength(0) - 1
            If i < Table.GetLength(0) \ 2 Then
                Device.DrawString("I" + i.ToString(), Font, Brushes.Black, New Point(StartX + (i * 25), StartY - 20))
            Else
                Device.DrawString("O" + (i - (Table.GetLength(0) \ 2)).ToString(), Font, Brushes.Black, New Point(StartX + (i * 25), StartY - 20))
            End If
            For j = 0 To Table.GetLength(1) - 1
                Dim StringPoint As Point = New Point(StartX + (i * 25), StartY + j * 25)
                If Table(i, j) = True Then
                    Device.DrawString("1", Font, Brushes.DarkRed, StringPoint)
                Else
                    Device.DrawString("0", Font, Brushes.Black, StringPoint)
                End If
            Next
        Next
        Device.DrawLine(Pen, New Point(StartX - 3 + ((Table.GetLength(0) \ 2) * 25), StartY), New Point(StartX - 3 + ((Table.GetLength(0) \ 2) * 25), StartY + (Table.GetLength(1) - 1) * 25 + 20))
        Dim ScoreText = "Score = " + Str(CS.Score)
        Dim ScoreX = 1000 + 150 - (TextRenderer.MeasureText(ScoreText, Font).Width \ 2)
        Device.DrawString(ScoreText, Font, Brushes.Black, New Point(ScoreX, 620))
    End Sub
    '' =================MOUSE EVENTS SUBS===============
    '' UPDATES THE SELECTED GATES POSISTION ON MOUSE POSISTION
    Private Sub CSMouseMove(ByVal sender As Object, ByVal e As MouseEventArgs)
        Dim Screen As CustomScreen = sender
        If Not (Screen.MovingGate Is Nothing) Then
            Screen.MovingGate.Position.X = (e.X * 1300 / Screen.Size.Width) - 50
            Screen.MovingGate.Position.Y = (e.Y * 800 / Screen.Size.Height) - 50
        End If
    End Sub
    '' GOES THROUGH THE APPROPRIATE CHECK ROUTINES
    Private Sub CSMouseDown(ByVal sender As Object, ByVal e As MouseEventArgs)
        Dim CS As CustomScreen = sender
        If CS.WireMode = False Then
            '' Not In WireMode
            If CS.MovingGate Is Nothing Then
                '' Not already moving an object
                CS.CheckForSpawn(e.X * 1300 / CS.Size.Width, e.Y * 800 / CS.Size.Height)
                If e.X * 1300 / CS.Size.Width > 1000 And e.Y * 800 / CS.Size.Height > 720 Then
                    CS.Undo(CS.Wires)
                ElseIf e.X * 1300 / CS.Size.Width > 1000 And e.Y * 800 / CS.Size.Height > 650 And e.Y * 800 / CS.Size.Height < 720 Then
                    CS.Check()
                End If
                CS.CheckForStageSelection(e.X * 1300 / CS.Size.Width, e.Y * 800 / CS.Size.Height)
            Else
                '' Check for a valid placement
                CS.CheckValidPlacement(e.X * 1300 / CS.Size.Width, e.Y * 800 / CS.Size.Height)
                CS.MovingGate = Nothing
            End If
        Else
            '' Check for wireplacement
            CS.CheckForSpawn(e.X * 1300 / CS.Size.Width, e.Y * 800 / CS.Size.Height)
            CS.CheckPort(e.X * 1300 / CS.Size.Width, e.Y * 800 / CS.Size.Height)
        End If
    End Sub
End Class

