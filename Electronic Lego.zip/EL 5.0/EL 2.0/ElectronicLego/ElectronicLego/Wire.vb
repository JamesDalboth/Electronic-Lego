﻿'' WIRE CLASS
Public Class Wire
    Public Port1 As port
    Public Port2 As port
    Public State As Boolean = False
    Public Sub CheckState()
        If Not Port1 Is Nothing Then
            If Port1.State = True And Port1.Type = False Then State = True
        End If
        If Not Port2 Is Nothing Then
            If Port2.State = True And Port2.Type = False Then State = True
        End If
        If State = True Then
            If Not Port1 Is Nothing Then
                Port1.State = True
            End If
            If Not Port2 Is Nothing Then
                Port2.State = True
            End If
        Else
            If Not Port1 Is Nothing Then
                Port1.State = False
            End If
            If Not Port2 Is Nothing Then
                Port2.State = False
            End If
        End If
    End Sub
    Public Sub Destory()
        If Not Port1 Is Nothing Then
            If Not Port1.PortWire.Count = 0 Then
                Port1.PortWire.Remove(Me)
            End If
        End If
        If Not Port2 Is Nothing Then
            If Not Port2.PortWire.Count = 0 Then
                Port2.PortWire.Remove(Me)
            End If
        End If
        MyBase.Finalize()
    End Sub
End Class

