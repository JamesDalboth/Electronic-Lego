﻿'' CUSTOM PICTURE BOX CLASS
Public Class CustomScreen
    Inherits PictureBox
    Public Gates As New List(Of Gate)
    Public Wires As New List(Of Wire)
    Public Buttons As New List(Of Button)
    Public GateSize As Integer = 100
    Public MovingGate As Gate = Nothing
    Public CurWire As Wire = Nothing
    Public WireMode As Boolean = Nothing
    Public Saving As Boolean = Nothing
    Public Exitapp As Boolean = Nothing
    Public Background As New Bitmap(1300, 800)
    Public Score As Integer
    Public Table(7, 15) As Boolean
    '' GENERATE NEW WIRE
    Public Sub NewWire()
        Dim NW = New Wire()
        CurWire = NW
        Wires.Add(NW)
    End Sub
    '' DESTROY THE CURRENT WIRE IF IN MIDDLE OF WIRE PLACEMENT
    Public Sub DestroyCurrentWire()
        Wires.Remove(CurWire)
        CurWire.Destory()
        CurWire = Nothing
    End Sub
    Public Sub SetWireToGate(ByVal Port As port, ByRef CurWire As Wire, ByRef Wires As List(Of Wire))
        '' SET WIRE TO A SPECIFIC PORT , if Wire already has port assigned then try next wire port.
        If CurWire.Port1 Is Nothing Then
            CurWire.Port1 = Port
        ElseIf CurWire.Port2 Is Nothing Then
            CurWire.Port2 = Port
            NewWire()
        End If
    End Sub
    Public Sub CheckPort(ByRef X As Integer, ByRef Y As Integer)
        For Each Gate In Gates
            Dim GateRectagle = New Rectangle(Gate.Position, New Size(GateSize, GateSize))
            If GateRectagle.Contains(X, Y) Then
                Dim Valid As Boolean = True
                For Each Inp In Gate.Inputs
                    For Each Wire In Inp.PortWire
                        If Wire Is CurWire Then Valid = False
                    Next
                Next
                For Each Out In Gate.Outputs
                    For Each Wire In Out.PortWire
                        If Wire Is CurWire Then Valid = False
                    Next
                Next
                If Valid = True Then
                    For Each Inp In Gate.Inputs.ToList()
                        If Inp.getlocationRect.Contains(X, Y) And Inp.PortWire.Count = 0 Then
                            Inp.PortWire.Add(CurWire)
                            SetWireToGate(Inp, CurWire, Wires)
                        End If
                    Next
                    For Each Out In Gate.Outputs.ToList()
                        If Out.getlocationRect.Contains(X, Y) Then
                            Out.PortWire.Add(CurWire)
                            SetWireToGate(Out, CurWire, Wires)
                        End If
                    Next
                End If
            End If
        Next
    End Sub
    '' UPDATES THE STATES OF THE WIRES/PORTS/GATES
    Public Sub CheckStates()
        For Each Gate In Gates
            Gate.CheckState()
        Next
        For Each Wire In Wires
            Wire.State = False
            Wire.CheckState()
        Next
    End Sub

    '' CHECKS IF TRYING TO SPAWN SOMETHING
    Public Sub CheckForSpawn(ByVal X As Integer, ByVal Y As Integer)
        For Each Btn In Buttons
            Dim BtnRect As New Rectangle(Btn.Location, New Size(GateSize, GateSize))
            If BtnRect.Contains(New Point(X, Y)) Then
                Btn.Click(Me, X, Y)
            End If
        Next
    End Sub
    '' CHECKS IF GATE CAN FIT THERE
    Public Sub CheckValidPlacement(ByVal X As Integer, ByVal Y As Integer)
        Dim Valid = True
        If X > 1300 - 350 Then Valid = False
        If X < 250 Then Valid = False
        If Y > 800 - 50 Then Valid = False
        If Y < 50 Then Valid = False
        Dim MovingGateRectangle = New Rectangle(MovingGate.Position, New Size(GateSize, GateSize))
        For Each Gate In gates
            If Not (Gate Is MovingGate) Then
                Dim GateRectagle = New Rectangle(Gate.Position, New Size(GateSize, GateSize))
                If GateRectagle.IntersectsWith(MovingGateRectangle) Then Valid = False
            End If
        Next
        If Valid = False Then
            For Each Inp In MovingGate.Inputs.ToList()
                For Each Wire In Inp.PortWire.ToList()
                    If Not Wire Is Nothing Then
                        Wires.Remove(Wire)
                    End If
                Next
            Next
            For Each Out In MovingGate.Outputs.ToList()
                For Each Wire In Out.PortWire.ToList()
                    If Not Wire Is Nothing Then
                        Wires.Remove(Wire)
                    End If
                Next
            Next
            gates.Remove(MovingGate)
            MovingGate.Destroy()
        End If
    End Sub
    '' CHECKS IF SELECTING A PLACED GATE
    Public Sub CheckForStageSelection(ByVal X As Integer, ByVal Y As Integer)
        ' Iterate through each gate in the gate list
        For Each Gate In Gates.ToList()
            '' Create a gate rectangle
            Dim GateRectangle = New Rectangle(Gate.Position, New Size(GateSize, GateSize))
            If GateRectangle.Contains(X, Y) Then
                '' If gate is a rectangle
                Gate.Click(X, Y, MovingGate, Gates)
            End If
        Next
    End Sub
    Public Sub Undo(ByRef Wires As List(Of Wire))
        If Wires.Count > 0 Then
            Wires(Wires.Count - 1).Destory()
            Wires.Remove(Wires(Wires.Count - 1))
        End If
    End Sub
    '' GAME ROUTINES
    Public Sub StartGame()
        Score = 0
        CreateTable()
        GenerateTable()
    End Sub
    Public Sub CreateTable()
        For i = 0 To 15
            Dim Binary = Convert.ToString(15 - i, 2).PadLeft(4, "0"c)
            For j = 0 To 3
                Select Case Binary(j)
                    Case "0"
                        Table(j, i) = False
                    Case "1"
                        Table(j, i) = True
                End Select
            Next
        Next
    End Sub
    Public Sub GenerateTable()
        Randomize()
        For i = 4 To 7
            Dim GateType = Int(6 * Rnd())
            Select Case GateType
                Case 0
                    Dim Input = Int(4 * Rnd())
                    For j = 0 To 15
                        Table(i, j) = Not Table(Input, j)
                    Next
                Case Else
                    Dim Input1 = Int(4 * Rnd())
                    Dim Input2 = Int(4 * Rnd())
                    While Input2 = Input1
                        Input2 = Int(4 * Rnd())
                    End While
                    Select Case GateType
                        Case 1
                            For j = 0 To 15
                                Table(i, j) = Table(Input1, j) And Table(Input2, j)
                            Next
                        Case 2
                            For j = 0 To 15
                                Table(i, j) = Table(Input1, j) Or Table(Input2, j)
                            Next
                        Case 3
                            For j = 0 To 15
                                Table(i, j) = Not (Table(Input1, j) And Table(Input2, j))
                            Next
                        Case 4
                            For j = 0 To 15
                                Table(i, j) = Not (Table(Input1, j) Or Table(Input2, j))
                            Next
                        Case 5
                            For j = 0 To 15
                                Table(i, j) = (Table(Input1, j) Xor Table(Input2, j))
                            Next
                    End Select
            End Select
        Next
    End Sub
    Public Sub Check()
        For i = 0 To 15
            Dim bin As String = Convert.ToString(15 - i, 2).PadLeft(4, "0"c)
            For count = 0 To 3
                Select Case bin(count)
                    Case "1"
                        Gates(count).State = True
                    Case "0"
                        Gates(count).State = False
                End Select
            Next
            For J = 0 To 20
                CheckStates()
            Next
            For j = 4 To 7
                If Table(j, i) <> Gates(j).Inputs(0).State Then
                    MsgBox("NO")
                    Exit Sub
                End If
            Next
        Next
        MsgBox("YES")
        Score += 100
        GenerateTable()
    End Sub
End Class

